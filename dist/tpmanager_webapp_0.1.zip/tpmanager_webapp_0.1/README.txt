TPTeam TPManager Webapp README


Author
======

Bob Brady, rpbrady@gmail.com
June 9, 2007


Purpose
=======

	This File describes the contents of the TPTeam TPManager
Web application release and how to install it.


Directory Contents
==================

Directories corresponding to those under a Tomcat home or similar
Web application server:

common/lib	Contains the java driver libraries for the MySQL and 
		Oracle XE databases.  These common libraries can be
		copied over the corresponding Web server directory.

conf		Contains a sample server.xml configuration file which
		a security realm configured for TPTeam.

webapps/bridge	Contains the TPManager Web application


Utiliity Directory:

sql		Scripts for creating the tpteam database, tpteam_ddl.sql,
		and populating it with seed data, tpteam_dml.sql.


Installation
=============

0. Dependicies
	The tpteam_plugin_deps release is required to be downloaded
and unpacked for the installation of TPManager.

1. Create & Populate the Database
	First run the tpteam_ddl.sql script to create the TPTeam table
structure and constraints.  Next, run tpteam_dml.sql to seed the 
database with an administrative rights user, tpteam1, having password
tpteam.

2. If Needed, Copy the Database Drivers 
	Copy the appropriate driver library from the common/lib directory
to the common library directory of the Web application server to be used.

3. Configure the Security Realm
	Use the included conf/sample_server.xml file as a guide.  It
uses the TPTeam database to enforce a JDBC security realm on a Tomcat
server.


4. Copy the TPManager Web Application 
	Copy the webapps/bridge directory over to the webapps directory
of the Web server to be used.

5. Copy the Plug-in Dependicies
	Download the tpteam_plugin_deps.  Copy all directories and
jar files from its plugins directory into the TPManager Web application
folder at this location:

	webapps > bridge > WEB-INF > eclipse > plugins


6. Configure the TPManager instance XMPP Account Properties
	Edit the tpteam.properties file located in the directory:

	webapps > bridge > WEB-INF > eclipse > plugins > 
	edu.harvard.fas.rbrady.tpteam.tpbridge_1.0.0 > data

	Change the tpmanager.ecfId and tpmanager.password properties
to those of the XMPP account to be used.

7. Configure Hibernate and Log4J
	Edit the hibernate.cfg.xml and log4j.properties files located
in the directory:
	
	webapps > bridge > WEB-INF > eclipse > plugins > 
	edu.harvard.fas.rbrady.tpteam.tpbridge_1.0.0

	Change the connection properties of Hibernate and log file
settings to the settings to be used.	


Usage
=====

0. Complete the installation steps above.

1. Make sure the database hosting TPTeam is running.

2. Start the Web server hosting the TPManager Web application.

3. Start a Web Browser, Finish Seeding Data
	
	* Go to the link http://yourTPTeamServer:8080/bridge/tpteam/admin/index.html,
where yourTPTeamServer:8080 is the Web server running an instance of TPManager.

	* Login as the default administrative user, tpteam1, with password tpteam.

	* Choose the appropriate actions from the form to:
		- Add a Product
		- Add a User
		- Add a Project
		- Add a Test Folder or Definition
		- Update/View/Delete the above items
		- Execute a Test
