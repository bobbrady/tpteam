TPTeam Plug-in Dependencies README


Author
======

Bob Brady, rpbrady@gmail.com
June 9, 2007


Purpose
=======

	This File describes the contents of the TPTeam Plug-in
Dependencies release and how to install it.


Distribution Contents
======================

All plug-in dependendcies are located under the plugins directory
of the unpacked release.


Installation
=============

0. Dependicies
	None, these are the plug-in dependencies of TPTeam!

1. Copy the Plug-in Dependicies
	Copy all directories and jar files from the plugins directory
into plugins directories specified in the TPBuddy and TPManager README files.
