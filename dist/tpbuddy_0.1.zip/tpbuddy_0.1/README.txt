TPTeam TPBuddy RCP Application README


Author
======

Bob Brady, rpbrady@gmail.com
June 9, 2007


Purpose
=======

	This File describes the contents of the TPTeam TPBuddy
RCP application release and how to install it.


Distribution Contents
==================

	The unpacked contents contains a standard RCP application 
layout.  Only one configuration file need be edited for standard
usage of TPBuddy.


Installation
=============

0. Dependicies
	The tpteam_plugin_deps release is required to be downloaded
and unpacked for the installation of TPBuddy


1. Copy the Plug-in Dependicies
	Download the tpteam_plugin_deps.  Copy all directories and
jar files from its plugins directory into the TPBuddy RCP application
plugin directory.


2. Configure the TPBuddy instance XMPP TPManager Properties
	Edit the tpteam.properties file located in the directory:

	plugins > edu.harvard.fas.rbrady.tpteam.tpbridge_1.0.0 > data

	Change the tpmanager.ecfId property to the XMPP account of the 
TPManager to be used.  The tpmanager.password property is not used and 
can remain at its default value.


Usage
=====

0. Complete the installation steps above.

1. Make sure the database hosting TPTeam is running.

2. Start the Web server hosting the TPManager Web application.

3. Click on the tpbuddy.exe Executable in the Unpacked Distribution Folder

	* The TPBuddy GUI should appear shortly.  Click on the person
	  icon to login to an XMPP account.

	* A list of available projects to the loggedin user should appear

	* Highlight a project row from the list, then click on the test tree
	  or project reports icons.

	* Click on the appropriate GUI icon to:
		- Add a Test Folder or Definition
		- Update/View/Delete a Test
		- Execute a Test

	* Real-time test execution results and test tree changes will
	  appear in the GUI.
